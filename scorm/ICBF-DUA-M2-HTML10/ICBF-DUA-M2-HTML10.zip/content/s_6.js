var slideTitle = "Slide N°1";
var slideContent = `
<div class="row last-container d-flex align-items-center">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="main-logo-header-center col-md-2 col-lg-1 col-2">
                <img class="img-fluid" src="./images/logo-header.png">
            </div>
        </div>
        <div class="row my-md-5 mt-xl-4 mb-xl-5 mb-lg-2 ">
            <div class="container my-md-5 mt-xl-4 mb-xl-5">
                <div class="row justify-content-center mt-3">
                    <div class="col-md-5 col-sm-12 welcome-image mt-5">
                        <img class="img-fluid" src="images/img_s1.png" alt="bienvenido">
                    </div>
                    <div class="col-md-7 col-sm-12 text-container align-items-center d-flex justify-content-center">
                        <div class="text-center">
                            <h2 class="tx-light-green my-4 mt-md-0">Ahora continúe revisando los demás recursos a su
                                disposición</h2>
                            <h1 class="tx-light-green">Diseño Universal</h1>
                            <h1 class="yellow-text">para el Aprendizaje</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
`;
var slideActivityContent = {};
